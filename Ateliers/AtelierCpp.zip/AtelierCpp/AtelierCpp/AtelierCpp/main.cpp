#include "Vecteur.h"

using namespace std;

int main()
{
    // Vous pouvez faire vos tests ici!
    // Le classique "Hello world!"
    cout << "Hello world!" << endl;
    return 0;
}
